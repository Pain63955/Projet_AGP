package api.text;

public class LuceneIndexService {

}
