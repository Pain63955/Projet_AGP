package api.visitor;

public interface OperatorVisitor {

}
