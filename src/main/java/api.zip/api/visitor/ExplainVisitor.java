package api.visitor;

public class ExplainVisitor implements OperatorVisitor {

}
