package api.visitor;

public class InitVisitor implements OperatorVisitor {

}
