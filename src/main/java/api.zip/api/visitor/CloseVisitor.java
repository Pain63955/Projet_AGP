package api.visitor;

public class CloseVisitor implements OperatorVisitor {

}
