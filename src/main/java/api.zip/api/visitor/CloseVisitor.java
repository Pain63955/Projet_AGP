package api.visitor;

import api.operators.JoinOperator;
import api.operators.SqlOperator;
import api.operators.TextOperator;

public class CloseVisitor implements OperatorVisitor {

	@Override
	public void visit(SqlOperator operator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(TextOperator operator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(JoinOperator operator) {
		// TODO Auto-generated method stub
		
	}

}
