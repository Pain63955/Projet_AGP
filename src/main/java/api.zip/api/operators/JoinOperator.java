package api.operators;

public class JoinOperator implements Operator {

}
