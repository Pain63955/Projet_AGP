package api.operators;

import api.visitor.OperatorVisitor;

public class JoinOperator implements Operator {

	@Override
	public void accept(OperatorVisitor visitor) {
		// TODO Auto-generated method stub
		
	}

}
