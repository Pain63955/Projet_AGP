package api.operators;

public abstract class AbstractOperator {

}
