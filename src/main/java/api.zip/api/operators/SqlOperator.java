package api.operators;

public class SqlOperator implements Operator {

}
