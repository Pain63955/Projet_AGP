package api.operators;

public interface Operator {

}
