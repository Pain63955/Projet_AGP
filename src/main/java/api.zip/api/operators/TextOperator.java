package api.operators;

public class TextOperator implements Operator {

}
