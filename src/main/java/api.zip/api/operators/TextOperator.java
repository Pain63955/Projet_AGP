package api.operators;

import api.visitor.OperatorVisitor;

public class TextOperator implements Operator {

	@Override
	public void accept(OperatorVisitor visitor) {
		// TODO Auto-generated method stub
		
	}

}
