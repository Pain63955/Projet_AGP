package api.core;

public class BDeStatement {

}
