package api.core;

public class BDeRow {

}
