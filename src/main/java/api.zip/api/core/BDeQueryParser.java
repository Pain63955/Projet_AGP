package api.core;

public class BDeQueryParser {

}
