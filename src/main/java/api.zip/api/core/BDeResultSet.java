package api.core;

public class BDeResultSet {

}
